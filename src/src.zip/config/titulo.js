module.exports = 'Monitoreo y respuesta de incidentes de seguridad digital'
